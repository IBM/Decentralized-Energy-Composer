## Script to setup Hyperledger Fabric 0.6
